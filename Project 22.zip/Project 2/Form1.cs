using System.Runtime.InteropServices;

namespace Project_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        public void CarregarUser(UserControl uc)
        {
            painel_principal.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            painel_principal.Controls.Add(uc);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Tela_cadastro telacad = new Tela_cadastro();
            Tela_login telalogin = new Tela_login();

            CarregarUser(telacad);
        }
    }
}
