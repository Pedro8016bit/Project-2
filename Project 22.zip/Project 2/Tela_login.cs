﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Tela_login : UserControl
    {
        public Tela_login()
        {
            InitializeComponent();
        }

        private void Lb_cad_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 Tela_principal = this.FindForm() as Form1;

            if (Tela_principal != null)
            {
                Tela_cadastro telacad = new Tela_cadastro();

                Tela_principal.CarregarUser(telacad);
            }
        }

        private void Lb_esqueci_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 Tela_principal = this.FindForm() as Form1;

            if (Tela_principal != null)
            {
                Tela_recuperar telarecuperar = new Tela_recuperar();

                Tela_principal.CarregarUser(telarecuperar);
            }
        }
    }
}
