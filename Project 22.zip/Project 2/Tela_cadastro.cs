﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Tela_cadastro : UserControl
    {
        public Tela_cadastro()
        {
            InitializeComponent();
        }

        private void btn_login_tela_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 Tela_principal = this.FindForm() as Form1;

            if (Tela_principal != null)
            {
                Tela_login telalogin = new Tela_login();

                Tela_principal.CarregarUser(telalogin);
            }
        }

        private void btn_Cad_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario usuario = new Usuario();
                usuario.Senha = txt_senha.Text;
                usuario.Email = txt_email.Text;
                usuario.Login = txt_login.Text;
                usuario.Nome = txt_nome.Text;

                if (!txt_nome.Text.Equals("") || !txt_senha.Text.Equals("") || !txt_email.Text.Equals("") || !txt_login.Text.Equals(""))
                {
                    bool cadastrado = usuario.CadastrarUser();
                    if (cadastrado)
                    {
                        MessageBox.Show("Cadastro feito com sucesso!!");
                        txt_nome.Clear();
                        txt_senha.Clear();
                        txt_email.Clear();
                        txt_login.Clear();
                        Tela_principal_programa telaprograma = new Tela_principal_programa();
                        this.Show();
                        
                    }
                    else
                    {
                        MessageBox.Show("Erro");

                    }

                }
                else
                {
                    MessageBox.Show("Erro ao realizar o cadastro!!");
                    txt_nome.Clear();
                    txt_senha.Clear();
                    txt_email.Clear();
                    txt_login.Clear();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("erro no catch da tela cadastro" + ex.Message);

            }
        }
    }
 }

