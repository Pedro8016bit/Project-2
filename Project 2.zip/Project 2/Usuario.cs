﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Project_2
{
    internal class Usuario
    {
        private string nome;
        private string login;
        private string email;
        private string senha;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Login
        {
            get { return login; }
            set { login = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }

        public bool CadastrarUser()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string inserir = "Insert INTO usuarios (nome, login, email, senha) values (@nome, @login, @email, @senha)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@login", Login);
                    comando.Parameters.AddWithValue("@senha", Senha);
                    comando.Parameters.AddWithValue("@Email", Email);

                    int resultado = Convert.ToInt32(comando.ExecuteNonQuery());

                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

            }
            catch (Exception ex)
            {
                return false;
                MessageBox.Show("erro ao cadastrar!!" + ex.Message);
            }
        }
    }
}
