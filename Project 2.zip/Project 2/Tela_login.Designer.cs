﻿namespace Project_2
{
    partial class Tela_login
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            groupBox1 = new GroupBox();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            label2 = new Label();
            label1 = new Label();
            btn_Cad = new Button();
            txt_senha = new TextBox();
            txt_login = new TextBox();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDark;
            panel1.Controls.Add(groupBox1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 470);
            panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonFace;
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(linkLabel2);
            groupBox1.Controls.Add(linkLabel1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btn_Cad);
            groupBox1.Controls.Add(txt_senha);
            groupBox1.Controls.Add(txt_login);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Location = new Point(70, 78);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(267, 287);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.Location = new Point(74, 260);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(118, 15);
            linkLabel2.TabIndex = 6;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Esqueci minha senha";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(99, 242);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(69, 15);
            linkLabel1.TabIndex = 5;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Cadastre-se";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 162);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 4;
            label2.Text = "Senha";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 110);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 3;
            label1.Text = "Login";
            // 
            // btn_Cad
            // 
            btn_Cad.BackColor = SystemColors.ControlDarkDark;
            btn_Cad.FlatStyle = FlatStyle.Flat;
            btn_Cad.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_Cad.ForeColor = SystemColors.Control;
            btn_Cad.Location = new Point(96, 213);
            btn_Cad.Name = "btn_Cad";
            btn_Cad.Size = new Size(75, 23);
            btn_Cad.TabIndex = 3;
            btn_Cad.Text = "Logar";
            btn_Cad.UseVisualStyleBackColor = false;
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(43, 180);
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(179, 23);
            txt_senha.TabIndex = 2;
            // 
            // txt_login
            // 
            txt_login.Location = new Point(43, 128);
            txt_login.Name = "txt_login";
            txt_login.Size = new Size(179, 23);
            txt_login.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlDarkDark;
            pictureBox1.Dock = DockStyle.Right;
            pictureBox1.Location = new Point(410, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(440, 470);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(103, 63);
            label3.Name = "label3";
            label3.Size = new Size(63, 22);
            label3.TabIndex = 7;
            label3.Text = "Login";
            // 
            // Tela_login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Tela_login";
            Size = new Size(850, 470);
            panel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private Button btn_Cad;
        private TextBox txt_senha;
        private TextBox txt_login;
        private PictureBox pictureBox1;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
        private Label label3;
    }
}
