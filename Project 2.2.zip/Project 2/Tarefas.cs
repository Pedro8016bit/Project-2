﻿using MySql.Data.MySqlClient;
using System;
using System.Text;
using System.Windows.Forms;

namespace Project_2
{
    internal class Tarefas
    {
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string Prioridade { get; set; }
        public string Data_dia { get; set; }
      
        public bool Adicinar_tarefa()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string query = "INSERT INTO tarefas (titulo, descricao, prioridade, data_dia) VALUES (@titulo, @descricao, @prioridade, @data_dia)";

                    MySqlCommand comando = new MySqlCommand(query, conexaoBanco);
                    comando.Parameters.AddWithValue("@titulo", Titulo);
                    comando.Parameters.AddWithValue("@descricao", Descricao);
                    comando.Parameters.AddWithValue("@prioridade", Prioridade);
                    comando.Parameters.AddWithValue("@data_dia", Data_dia);

                    int resultado = comando.ExecuteNonQuery();

                    if (resultado > 0)
                    {
                        MessageBox.Show("Tarefa cadastrada com sucesso!");
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao cadastrar tarefa.");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar item: " + ex.Message);
                return false;
            }
        }
    }
}

