﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Project_2
{
    internal class Usuario
    {
        private string nome;
        private string login;
        private string email;
        private string senha;
        private string id_user;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Login
        {
            get { return login; }
            set { login = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }
        public string Id_user
        {
            get { return id_user; }
            set { Id_user = value; }
        }

        public bool CadastrarUser()
        {
            try
            {
                if (!verificarEmail(Email))
                {
                    MessageBox.Show("erro ao verificar Email");
                    return false;
                }

                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string senhacripto = CriptografarSenha(Senha); 
                    string inserir = "Insert INTO usuarios (nome, login, email, senha) values (@nome, @login, @email, @senha)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@login", Login);
                    comando.Parameters.AddWithValue("@senha", senhacripto);
                    comando.Parameters.AddWithValue("@Email", Email);

                    int resultado = Convert.ToInt32(comando.ExecuteNonQuery());

                    if (resultado > 0)
                    {
                        MessageBox.Show("usuario cadastrado com sucesso!!");
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao cadastrar!!" + ex.Message);
                return false;
                
            }
        }

        public static bool verificarEmail(string email)
        {
            string emailValido = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(emailValido);
            return regex.IsMatch(email);
        }

        public static string CriptografarSenha(string senha)
        {
            try
            {
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha ?? ""));
                    StringBuilder builder = new StringBuilder();
                    foreach (byte b in bytes)
                        builder.Append(b.ToString("x2"));
                    return builder.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível criptografar a senha: " + ex.Message, "Erro - Método Criptografar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return "";
            }
        }

        public bool Redefinirsenha(string email, string senha)
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string senhacripto = CriptografarSenha(senha);

                    string update = "UPDATE usuarios SET senha = @senha WHERE email = @email";

                    MySqlCommand comando = new MySqlCommand(update, conexaoBanco);
                    comando.Parameters.AddWithValue("@senha", senhacripto);
                    comando.Parameters.AddWithValue("@email", email);

                    int resultado = Convert.ToInt32(comando.ExecuteNonQuery());

                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao redefinir!!" + ex.Message);
                return false;
            }
        }

        public bool Logar(string login, string senha)
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string senhacripto = CriptografarSenha(senha);

                    string logar = "SELECT id FROM usuarios WHERE login = @login AND senha = @senha";

                    MySqlCommand comando = new MySqlCommand(logar, conexaoBanco);
                    comando.Parameters.AddWithValue("@login", login);
                    comando.Parameters.AddWithValue("@senha", senhacripto);

                    object result = comando.ExecuteScalar();

                    if (result != null)
                    {
                        MessageBox.Show("Login realizado com sucesso!");
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao realizar login :(");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao realizar o comando do login: " + ex.Message);
                return false;
            }
        }


    }
}
