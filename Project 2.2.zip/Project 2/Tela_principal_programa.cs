﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Project_2
{
    public partial class Tela_principal_programa : Form
    {
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        public Tela_principal_programa()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Tarefas tare = new Tarefas();
            tare.Titulo = txt_nome_tarefa.Text;
            tare.Data_dia = txt_data.Text;
            tare.Prioridade = txt_prioridade.Text;
            tare.Descricao = txt_tarefa.Text;


            bool funciona = tare.Adicinar_tarefa();

            if (!funciona)
            {
                MessageBox.Show("Erro ao adicionar a tarefa.");
            }
        }

        private void CarregarTodasTarefas()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "SELECT titulo, descricao, prioridade, data_dia FROM tarefas";

                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adapter.Fill(tabela);

                    dataGridViewTarefas.DataSource = tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar tarefas: " + ex.Message);
            }
        }

        private void Tela_principal_programa_Load(object sender, EventArgs e)
        {
            CarregarTodasTarefas();
        }
    }
}
