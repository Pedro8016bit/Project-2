﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Tela_login : UserControl
    {
        public Tela_login()
        {
            InitializeComponent();
        }

        private void Lb_cad_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 Tela_principal = this.FindForm() as Form1;

            if (Tela_principal != null)
            {
                Tela_cadastro telacad = new Tela_cadastro();

                Tela_principal.CarregarUser(telacad);
            }
        }

        private void Lb_esqueci_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 Tela_principal = this.FindForm() as Form1;

            if (Tela_principal != null)
            {
                Tela_recuperar telarecuperar = new Tela_recuperar();

                Tela_principal.CarregarUser(telarecuperar);
            }
        }

        private void btn_Cad_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario();
            usuario.Login = txt_login.Text;
            usuario.Senha = txt_senha.Text;

            if(!txt_login.Text.Equals("") && !txt_senha.Text.Equals(""))
            {
                bool logado = usuario.Logar(usuario.Login, usuario.Senha);

                if (logado)
                {
                    Form1 Tela_principal = this.FindForm() as Form1;

                    Tela_principal_programa telapro = new Tela_principal_programa();
                    telapro.Show();
                    Tela_principal.Hide();
                }

            }
        }
    }
}
