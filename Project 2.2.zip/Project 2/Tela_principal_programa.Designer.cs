﻿namespace Project_2
{
    partial class Tela_principal_programa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_principal_programa));
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            label5 = new Label();
            txt_nome_tarefa = new TextBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            txt_prioridade = new ComboBox();
            txt_mostrar_atividade = new Label();
            label4 = new Label();
            label3 = new Label();
            txt_data = new MaskedTextBox();
            label2 = new Label();
            txt_tarefa = new TextBox();
            label1 = new Label();
            dataGridViewTarefas = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTarefas).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 30);
            panel1.TabIndex = 19;
            panel1.MouseDown += panel1_MouseDown;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(779, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(24, 24);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 20;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(814, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 20;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label5);
            panel2.Controls.Add(txt_nome_tarefa);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(txt_prioridade);
            panel2.Controls.Add(txt_mostrar_atividade);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(txt_data);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(txt_tarefa);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(dataGridViewTarefas);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 30);
            panel2.Name = "panel2";
            panel2.Size = new Size(850, 440);
            panel2.TabIndex = 20;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(477, 44);
            label5.Name = "label5";
            label5.Size = new Size(75, 15);
            label5.TabIndex = 32;
            label5.Text = "Tarefa nome:";
            // 
            // txt_nome_tarefa
            // 
            txt_nome_tarefa.Location = new Point(477, 62);
            txt_nome_tarefa.Name = "txt_nome_tarefa";
            txt_nome_tarefa.Size = new Size(100, 23);
            txt_nome_tarefa.TabIndex = 31;
            // 
            // button3
            // 
            button3.Location = new Point(737, 188);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 30;
            button3.Text = "Excluir";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(605, 188);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 29;
            button2.Text = "Criar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(477, 188);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 28;
            button1.Text = "Editar";
            button1.UseVisualStyleBackColor = true;
            // 
            // txt_prioridade
            // 
            txt_prioridade.FormattingEnabled = true;
            txt_prioridade.Items.AddRange(new object[] { "Pouco Importante", "Media Importancia", "Muito Importante" });
            txt_prioridade.Location = new Point(477, 106);
            txt_prioridade.Name = "txt_prioridade";
            txt_prioridade.Size = new Size(121, 23);
            txt_prioridade.TabIndex = 27;
            // 
            // txt_mostrar_atividade
            // 
            txt_mostrar_atividade.AutoSize = true;
            txt_mostrar_atividade.Location = new Point(479, 247);
            txt_mostrar_atividade.Name = "txt_mostrar_atividade";
            txt_mostrar_atividade.Size = new Size(89, 15);
            txt_mostrar_atividade.TabIndex = 26;
            txt_mostrar_atividade.Text = "<<Atividade>>";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(637, 88);
            label4.Name = "label4";
            label4.Size = new Size(34, 15);
            label4.TabIndex = 25;
            label4.Text = "Data:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(477, 88);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 24;
            label3.Text = "Prioridade:";
            // 
            // txt_data
            // 
            txt_data.Location = new Point(637, 106);
            txt_data.Mask = "00/00/0000";
            txt_data.Name = "txt_data";
            txt_data.Size = new Size(100, 23);
            txt_data.TabIndex = 23;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(477, 141);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 22;
            label2.Text = "Atividade:";
            // 
            // txt_tarefa
            // 
            txt_tarefa.Location = new Point(477, 159);
            txt_tarefa.Name = "txt_tarefa";
            txt_tarefa.Size = new Size(335, 23);
            txt_tarefa.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(479, 222);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 20;
            label1.Text = "Atividade:";
            // 
            // dataGridViewTarefas
            // 
            dataGridViewTarefas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTarefas.Location = new Point(65, 16);
            dataGridViewTarefas.Name = "dataGridViewTarefas";
            dataGridViewTarefas.Size = new Size(341, 412);
            dataGridViewTarefas.TabIndex = 19;
            // 
            // Tela_principal_programa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(850, 470);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Tela_principal_programa";
            Text = "Tela_principal_programa";
            Load += Tela_principal_programa_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTarefas).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Panel panel2;
        private ComboBox txt_prioridade;
        private Label txt_mostrar_atividade;
        private Label label4;
        private Label label3;
        private MaskedTextBox txt_data;
        private Label label2;
        private TextBox txt_tarefa;
        private Label label1;
        private DataGridView dataGridViewTarefas;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label5;
        private TextBox txt_nome_tarefa;
    }
}