﻿namespace Project_2
{
    partial class Tela_login
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_login));
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            groupBox1 = new GroupBox();
            label3 = new Label();
            Lb_esqueci = new LinkLabel();
            Lb_cad = new LinkLabel();
            label2 = new Label();
            label1 = new Label();
            btn_Cad = new Button();
            txt_senha = new TextBox();
            txt_login = new TextBox();
            pictureBox3 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDark;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(groupBox1);
            panel1.Controls.Add(pictureBox3);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 470);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlDarkDark;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(444, 45);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(380, 329);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonFace;
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(Lb_esqueci);
            groupBox1.Controls.Add(Lb_cad);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btn_Cad);
            groupBox1.Controls.Add(txt_senha);
            groupBox1.Controls.Add(txt_login);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Location = new Point(70, 78);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(267, 287);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(103, 63);
            label3.Name = "label3";
            label3.Size = new Size(63, 22);
            label3.TabIndex = 7;
            label3.Text = "Login";
            // 
            // Lb_esqueci
            // 
            Lb_esqueci.AutoSize = true;
            Lb_esqueci.Location = new Point(74, 260);
            Lb_esqueci.Name = "Lb_esqueci";
            Lb_esqueci.Size = new Size(118, 15);
            Lb_esqueci.TabIndex = 6;
            Lb_esqueci.TabStop = true;
            Lb_esqueci.Text = "Esqueci minha senha";
            Lb_esqueci.LinkClicked += Lb_esqueci_LinkClicked;
            // 
            // Lb_cad
            // 
            Lb_cad.AutoSize = true;
            Lb_cad.Location = new Point(99, 242);
            Lb_cad.Name = "Lb_cad";
            Lb_cad.Size = new Size(69, 15);
            Lb_cad.TabIndex = 5;
            Lb_cad.TabStop = true;
            Lb_cad.Text = "Cadastre-se";
            Lb_cad.LinkClicked += Lb_cad_LinkClicked;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 162);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 4;
            label2.Text = "Senha";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 110);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 3;
            label1.Text = "Login";
            // 
            // btn_Cad
            // 
            btn_Cad.BackColor = SystemColors.ControlDarkDark;
            btn_Cad.FlatStyle = FlatStyle.Flat;
            btn_Cad.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_Cad.ForeColor = SystemColors.Control;
            btn_Cad.Location = new Point(96, 213);
            btn_Cad.Name = "btn_Cad";
            btn_Cad.Size = new Size(75, 26);
            btn_Cad.TabIndex = 3;
            btn_Cad.Text = "Logar";
            btn_Cad.UseVisualStyleBackColor = false;
            btn_Cad.Click += btn_Cad_Click;
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(43, 180);
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(179, 23);
            txt_senha.TabIndex = 2;
            // 
            // txt_login
            // 
            txt_login.Location = new Point(43, 128);
            txt_login.Name = "txt_login";
            txt_login.Size = new Size(179, 23);
            txt_login.TabIndex = 1;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.ControlDarkDark;
            pictureBox3.Dock = DockStyle.Right;
            pictureBox3.Location = new Point(410, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(440, 470);
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            // 
            // Tela_login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Tela_login";
            Size = new Size(850, 470);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private GroupBox groupBox1;
        private Label label3;
        private LinkLabel Lb_esqueci;
        private LinkLabel Lb_cad;
        private Label label2;
        private Label label1;
        private Button btn_Cad;
        private TextBox txt_senha;
        private TextBox txt_login;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
    }
}
