﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Tela_recuperar : UserControl
    {
        public Tela_recuperar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 Tela_principal = this.FindForm() as Form1;

            if (Tela_principal != null)
            {
                Tela_login telarecuperar = new Tela_login();

                Tela_principal.CarregarUser(telarecuperar);
            }
        }

        private void btn_Cad_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario();

            usuario.Email = txt_login.Text;
            usuario.Senha = txt_senha.Text;

            if(!txt_login.Text.Equals("") && !txt_senha.Text.Equals(""))
            {
                
                bool funciona = usuario.Redefinirsenha(usuario.Email, usuario.Senha);
                if (funciona)
                {
                    MessageBox.Show("Senha Atualizada!!");
                }
                else
                {
                    MessageBox.Show("erro ao atualizar senha");
                }

            }
            
        }
    }
}
