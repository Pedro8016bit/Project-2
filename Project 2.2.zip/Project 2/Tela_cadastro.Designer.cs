﻿namespace Project_2
{
    partial class Tela_cadastro
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            groupBox1 = new GroupBox();
            btn_login_tela = new LinkLabel();
            label5 = new Label();
            label3 = new Label();
            label4 = new Label();
            txt_email = new TextBox();
            txt_nome = new TextBox();
            label2 = new Label();
            label1 = new Label();
            btn_Cad = new Button();
            txt_senha = new TextBox();
            txt_login = new TextBox();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDark;
            panel1.Controls.Add(groupBox1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 470);
            panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonFace;
            groupBox1.Controls.Add(btn_login_tela);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txt_email);
            groupBox1.Controls.Add(txt_nome);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btn_Cad);
            groupBox1.Controls.Add(txt_senha);
            groupBox1.Controls.Add(txt_login);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Location = new Point(70, 78);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(267, 287);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // btn_login_tela
            // 
            btn_login_tela.AutoSize = true;
            btn_login_tela.Location = new Point(162, 258);
            btn_login_tela.Name = "btn_login_tela";
            btn_login_tela.Size = new Size(37, 15);
            btn_login_tela.TabIndex = 10;
            btn_login_tela.TabStop = true;
            btn_login_tela.Text = "Login";
            btn_login_tela.LinkClicked += btn_login_tela_LinkClicked;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(54, 258);
            label5.Name = "label5";
            label5.Size = new Size(92, 15);
            label5.TabIndex = 9;
            label5.Text = "Já possui conta?";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(43, 88);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 8;
            label3.Text = "Email";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(45, 44);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 7;
            label4.Text = "Nome";
            // 
            // txt_email
            // 
            txt_email.Location = new Point(43, 106);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(179, 23);
            txt_email.TabIndex = 6;
            // 
            // txt_nome
            // 
            txt_nome.Location = new Point(43, 62);
            txt_nome.Name = "txt_nome";
            txt_nome.Size = new Size(179, 23);
            txt_nome.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 176);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 4;
            label2.Text = "Senha";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 132);
            label1.Name = "label1";
            label1.Size = new Size(37, 15);
            label1.TabIndex = 3;
            label1.Text = "Login";
            // 
            // btn_Cad
            // 
            btn_Cad.BackColor = SystemColors.ControlDarkDark;
            btn_Cad.FlatStyle = FlatStyle.Flat;
            btn_Cad.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_Cad.ForeColor = SystemColors.Control;
            btn_Cad.Location = new Point(100, 232);
            btn_Cad.Name = "btn_Cad";
            btn_Cad.Size = new Size(75, 23);
            btn_Cad.TabIndex = 3;
            btn_Cad.Text = "Cadastar";
            btn_Cad.UseVisualStyleBackColor = false;
            btn_Cad.Click += btn_Cad_Click;
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(43, 194);
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(179, 23);
            txt_senha.TabIndex = 2;
            // 
            // txt_login
            // 
            txt_login.Location = new Point(43, 150);
            txt_login.Name = "txt_login";
            txt_login.Size = new Size(179, 23);
            txt_login.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlDarkDark;
            pictureBox1.Dock = DockStyle.Right;
            pictureBox1.Location = new Point(410, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(440, 470);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Tela_cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "Tela_cadastro";
            Size = new Size(850, 470);
            panel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private GroupBox groupBox1;
        private Button btn_Cad;
        private TextBox txt_senha;
        private TextBox txt_login;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private TextBox txt_email;
        private TextBox txt_nome;
        private LinkLabel btn_login_tela;
        private Label label5;
    }
}
